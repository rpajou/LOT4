#Packages needed

if(!require(rmarkdown)){install.packages("rmarkdown")}
suppressPackageStartupMessages(library(rmarkdown))
if(!require(stringr)){install.packages("stringr")}
suppressPackageStartupMessages(library(stringr))
if(!require(data.table)){install.packages("data.table")}
suppressPackageStartupMessages(library(data.table))
if(!require(knitr)){install.packages("knitr")}
suppressPackageStartupMessages(library(knitr))
if(!require(DT)){install.packages("DT")}
suppressPackageStartupMessages(library(DT))
if(!require(plyr)){install.packages("plyr")}
suppressPackageStartupMessages(library(plyr))
if(!require(ggplot2)){install.packages("ggplot2")}
suppressPackageStartupMessages(library(ggplot2))
if(!require(plotly)){install.packages("plotly")}
suppressPackageStartupMessages(library(plotly))
if(!require(lubridate)){install.packages("lubridate")}
suppressPackageStartupMessages(library(lubridate))
if(!require(grid)){install.packages("grid")}
suppressPackageStartupMessages(library(grid))
if(!require(e1071)){install.packages("e1071")}
suppressPackageStartupMessages(library(e1071))
if(!require(rlist)){install.packages("rlist")}
suppressPackageStartupMessages(library(rlist))
if(!require(colorRamps)){install.packages("colorRamps")}
suppressPackageStartupMessages(library(colorRamps))